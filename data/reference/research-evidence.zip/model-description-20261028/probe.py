import sys,os,json,hashlib,ast,torch,numpy as np,contextlib,io
from pathlib import Path
p=Path('/root/gpufree-data/DTAAD/DTAAD_64_n_method_2');os.chdir(p);sys.path.insert(0,str(p));sys.argv=['audit','--model','DTAAD','--dataset','converter','--Device','cpu'];torch.set_num_threads(2)
checks={}
for name in ['DTAAD_64_n','DTAAD_64_n_method_2']:
 root=p.parent/name
 checks[name]={str(f):hashlib.sha256((root/f).read_bytes()).hexdigest() for f in ['src/models.py','src/dlutils.py','src/gltcn.py','adaptive_mask.py','BNDLosswithW_single.py','newMain17.py','checkpoints/DTAAD_converter/model.ckpt']}
with contextlib.redirect_stdout(io.StringIO()):
 from src.models import DTAAD
 from BNDLosswithW_single import BNDLoss
 m=DTAAD(125).double().eval();m.load_state_dict(torch.load(p/'checkpoints/DTAAD_converter/model.ckpt',map_location='cpu',weights_only=False)['model_state_dict'])
 data=np.load(p/'processed/converter/converter_test.npy');d=torch.from_numpy(data[107:171][None]);dm=d.clone();dm[:,16:32]=0
 with torch.inference_mode():
  original=m(d,dm);h=m.st_fusion.register_forward_hook(lambda mod,args,out: torch.zeros_like(out)+1000);replaced=m(d,dm);h.remove()
 m.zero_grad();out=m(d,dm);out.square().mean().backward()
 reconstruction_grads=[n for n,v in m.named_parameters() if v.grad is not None and bool(v.grad.abs().sum()>0)]
 m.zero_grad();out=m(d,dm);labels=torch.from_numpy(np.load(p/'processed/converter/converter_labels.npy')[107:171][None]);loss_fn=BNDLoss(.1,.2);reg=loss_fn.spatial_anomaly_ratio(m.attn_spatial,labels);reg.backward()
 regularizer_grads=[n for n,v in m.named_parameters() if v.grad is not None and bool(v.grad.abs().sum()>0)]
 # Extract pure mask builders without executing training entry point.
 tree=ast.parse((p/'newMain17.py').read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['compute_spatial_mask','compute_global_spatial_mask']];scope={'torch':torch};exec(compile(ast.Module(body=nodes,type_ignores=[]),'mask-builders','exec'),scope)
 train=torch.from_numpy(np.load(p/'processed/converter/converter_train.npy'));mask=scope['compute_global_spatial_mask'](train)
 with torch.inference_mode():
  masked_out=m(d,dm,mask);att=m.attn_spatial.mean(1)[0]
 mask_stats={'true_count':int(mask.sum()),'shape':list(mask.shape),'attention_abs_max_at_true':float(att[mask].abs().max()),'attention_mean_at_false':float(att[~mask].mean()),'output_difference_with_spatial_mask':float((original-masked_out).abs().max()),'finite_attention':bool(torch.isfinite(att).all())}
 from adaptive_mask import adaptive_period,random_masking
 periods=adaptive_period(data[107:171][None],5);_,realized=random_masking(torch.from_numpy(data[107:171][None].copy()),periods)
 mask_span={'period_min':float(np.min(periods)),'period_max':float(np.max(periods)),'zero_counts_unique':np.unique((realized==0).sum(1)).tolist()}
 # Bounded loss derivative with respect to MSE, rather than model weights.
 err=torch.tensor([.01,.5],requires_grad=True);normal=torch.relu(.2+err);anomaly=torch.relu(.2-err);grad=torch.autograd.grad(anomaly.sum(),err)[0]
output={'torch':torch.__version__,'hashes':checks,'fusion_replaced_max_output_difference':float((original-replaced).abs().max()),'reconstruction_grads_in_spatial_or_fusion':[n for n in reconstruction_grads if n.startswith(('spatial_encoder','st_fusion'))],'regularizer_gradient_parameter_names':regularizer_grads,'gradient_parameter_overlap':sorted(set(regularizer_grads)&set(reconstruction_grads)),'spatial_mask':mask_stats,'temporal_mask':mask_span,'bounded_loss':{'anomaly_values':anomaly.tolist(),'d_loss_d_error':grad.tolist(),'spatial_regularizer_effective_weight':loss_fn._lambda}}
print(json.dumps(output,indent=2))
