import sys,os,json,torch,numpy as np,contextlib,io
p='/root/gpufree-data/DTAAD/DTAAD_64_n_method_2';os.chdir(p);sys.path.insert(0,p);sys.argv=['audit','--model','DTAAD','--dataset','converter'];torch.set_num_threads(2)
with contextlib.redirect_stdout(io.StringIO()):
 from src.models import DTAAD
 m=DTAAD(125).double().eval();m.load_state_dict(torch.load('checkpoints/DTAAD_converter/model.ckpt',map_location='cpu',weights_only=False)['model_state_dict'])
 d=torch.from_numpy(np.load('processed/converter/converter_test.npy')[:64][None]);mask=torch.ones_like(d);mask[:,16:32]=0
 with torch.inference_mode():
  original=m(d,d*mask);h=m.st_fusion.register_forward_hook(lambda mod,args,out: torch.zeros_like(out)+1000);replaced=m(d,d*mask);h.remove()
 m.zero_grad();m(d,d*mask).square().mean().backward()
 printout={'fusion_output_replaced_by_1000_max_prediction_difference':float((original-replaced).abs().max()),'fusion_weight_has_reconstruction_gradient':m.st_fusion.weight.grad is not None,'fusion_bias_has_reconstruction_gradient':m.st_fusion.bias.grad is not None}
print(json.dumps(printout,indent=2))