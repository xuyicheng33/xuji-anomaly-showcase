import json,numpy as np,pandas as pd
b='/root/gpufree-data/DTAAD';X=pd.read_excel(b+'/data/dataset/orgdata/convertertrain.xlsx').iloc[:,1:].to_numpy(float);Y=pd.read_excel(b+'/data/dataset/orgdata/convertertest.xlsx').iloc[:,1:126].to_numpy(float);test=np.load(b+'/DTAAD_64_n/processed/converter/converter_test.npy');labels=np.load(b+'/DTAAD_64_n/processed/converter/converter_labels.npy')!=0
r={}
for nm,fit in [('train_dropfirst',X[1:]),('train_all',X),('test_dropfirst',Y[1:]),('global',np.r_[X,Y])]:
 lo=fit.min(0);den=fit.max(0)-lo;den[den==0]=1
 a=(Y[1:]-lo)/den;diff=abs(a-test)
 r[nm]={'first_8':a[0,:8].tolist(),'unlabeled_max':float(diff[~labels].max()),'unlabeled_mean':float(diff[~labels].mean()),'unlabeled_changed_1e_6':int((diff[~labels]>1e-6).sum()),'labeled_changed_1e_6':int((diff[labels]>1e-6).sum()),'unlabeled_cells':int((~labels).sum())}
for folder in ['DTAAD_64_n/processed/converterold','DTAAD-main/processed/converter','traditional/converter']:
 a=np.load(b+'/'+folder+'/converter_test.npy');diff=abs(a-test);r[folder]={'shape':a.shape,'max_abs':float(diff.max()),'unlabeled_max':float(diff[~labels].max()),'changed_1e_6':int((diff>1e-6).sum()),'first_8':a[0,:8].tolist()}
print(json.dumps(r,indent=2))