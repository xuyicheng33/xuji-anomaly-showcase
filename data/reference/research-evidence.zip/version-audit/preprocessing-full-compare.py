import os,json,numpy as np,pandas as pd
b='/root/gpufree-data/DTAAD/data/dataset';r={}
raw=pd.read_excel(b+'/converter.xlsx',sheet_name='Sheet8');mid=pd.read_excel(b+'/orgdata/converter.xlsx',sheet_name='Sheet8');cl=pd.read_excel(b+'/orgdata/converternew.xlsx');trxl=pd.read_excel(b+'/orgdata/convertertrain.xlsx')
r['raw_columns']=list(map(str,raw.columns));r['raw_time_head']=raw.iloc[:3,0].astype(str).tolist();r['clean_time_head']=cl.iloc[:3,0].astype(str).tolist()
features=list(cl.columns[1:]);raw.columns=raw.columns.map(str);cl.columns=cl.columns.map(str)
raw.index=pd.to_datetime(raw.iloc[:,0],errors="coerce");r["raw_invalid_timestamps"]=int(raw.index.isna().sum());raw=raw.loc[~raw.index.isna()];cl.index=pd.to_datetime(cl.iloc[:,0]);ret=raw.reindex(cl.index)[features].apply(pd.to_numeric,errors='coerce').to_numpy();X=cl[features].to_numpy(float);missing=~np.isfinite(ret);finite=~missing
r['raw_to_clean']={'raw_rows':len(raw),'clean_rows':len(cl),'dropped_rows':len(raw.index.difference(cl.index)),'dropped_columns':[x for x in raw.columns[1:] if x not in features],'missing_retained_cells':int(missing.sum()),'missing_to_zero':int((X[missing]==0).sum()),'missing_to_nonzero':int((X[missing]!=0).sum()),'finite_changed_exact':int((ret[finite]!=X[finite]).sum()),'finite_changed_tol1e_8':int((abs(ret[finite]-X[finite])>1e-8).sum()),'finite_change_max':float(abs(ret[finite]-X[finite]).max()),'dropped_time_first':str(raw.index.difference(cl.index).min()),'dropped_time_last':str(raw.index.difference(cl.index).max()),'missing_clean_cells':int((~np.isfinite(X)).sum())}
mv=mid.iloc[:,1:].apply(pd.to_numeric,errors='coerce').to_numpy();r['mid_missing_cells']=int((~np.isfinite(mv)).sum());r['mid_equal_clean_after_fill0']=bool(np.allclose(np.nan_to_num(mv),X,rtol=0,atol=1e-9))
tv=trxl.iloc[:,1:].to_numpy(float);r['train_workbook_vs_clean']={'shape':tv.shape,'changed_exact':int((tv!=X[:len(tv)]).sum()),'changed_tol1e_8':int((abs(tv-X[:len(tv)])>1e-8).sum()),'max_abs':float(abs(tv-X[:len(tv)]).max())}
orig=np.load(b+'/orgdata/converter_test.npy');test=np.load('/root/gpufree-data/DTAAD/DTAAD_64_n/processed/converter/converter_test.npy');lab=np.load('/root/gpufree-data/DTAAD/DTAAD_64_n/processed/converter/converter_labels.npy')!=0
r['test_vs_clean_tolerances']={}
for tol in [0,1e-7,1e-6,1e-5]:
 diff=abs(test-orig)>tol;r['test_vs_clean_tolerances'][str(tol)]={'changed':int(diff.sum()),'unlabeled':int((diff&~lab).sum()),'labeled_unchanged':int((~diff&lab).sum()),'changed_points':int(diff.any(1).sum())}
r['unlabeled_maxdiff']=float(abs(test-orig)[~lab].max())
for rel in ['prodata/converter_test.npy','inserteddata/converter_test_seq.npy']:
 a=np.load(b+'/'+rel);diff=abs(a-test)>1e-6;r[rel]={'max_abs':float(abs(a-test).max()),'changed_tol1e_6':int(diff.sum())}
print(json.dumps(r,ensure_ascii=False,indent=2))