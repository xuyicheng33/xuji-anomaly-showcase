import os,sys,json,ast,hashlib,numpy as np,contextlib,io
b='/root/gpufree-data/DTAAD';r={};sys.path.insert(0,b+'/DTAAD_64_n');sys.argv=['audit','--dataset','converter'];from src.spot import SPOT
for mod,th in [('DTAAD_64_n',.03153185243407894),('DTAAD_64_n_method_2',.03197041806617129)]:
 root=b+'/'+mod;label=np.load(root+'/processed/converter/converter_labels.npy').any(1);rec={};ns={'np':np}
 tree=ast.parse(open(root+'/newMain17.py').read());fun=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='calculate_finalLoss'][0];exec(compile(ast.Module(body=[fun],type_ignores=[]),'audit','exec'),ns)
 a=np.load(root+'/Loss/test/trainLoss.npy');agg=ns['calculate_finalLoss'](a,64).mean(1)
 with contextlib.redirect_stdout(io.StringIO()):
  s=SPOT(1e-5);s.fit(agg,np.empty(0));s.initialize(level=.99,min_extrema=False,verbose=False)
 rec['pot_from_archived_trainLoss']={'value':float(s.extreme_quantile),'samples':len(agg),'mean':float(agg.mean()),'quantiles':np.quantile(agg,[.5,.9,.99,1]).tolist()}
 candidates=['score_plots/lossFinal.npy','reconstructed/epochtest_fusion.npy','reconstructed/epochtest_fusion_mse.npy','viz/data/lossFinal.npy','viz/data/lossPerFeat.npy','draw_attn/epochtest_fusion_mse.npy']
 for rel in candidates:
  p=root+'/'+rel
  if not os.path.exists(p):continue
  a=np.load(p,mmap_mode='r');x={'shape':a.shape,'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest()}
  if a.shape[0]==len(label) and 'fusion.npy' not in rel:
   scores=a.mean(1) if a.ndim==2 else a if a.ndim==1 else None
   if scores is not None:
    def metrics(pred):
     tp=int((pred&label).sum());fp=int((pred&~label).sum());fn=int((~pred&label).sum());tn=int((~pred&~label).sum());return {'tp':tp,'fp':fp,'fn':fn,'tn':tn,'f1':2*tp/(2*tp+fp+fn)}
    pred=scores>th;pa=pred.copy();bounds=np.flatnonzero(np.diff(np.r_[0,label,0])).reshape(-1,2)
    for l,h in bounds:
     if pred[l:h].any():pa[l:h]=True
    x['pw']=metrics(pred);x['pa']=metrics(pa)
  rec[rel]=x
 r[mod]=rec
print(json.dumps(r,indent=2))