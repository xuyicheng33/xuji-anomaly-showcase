import os,json,hashlib,numpy as np,pandas as pd
b='/root/gpufree-data/DTAAD';d=b+'/data/dataset';r={}
for rel in ['converter.xlsx','orgdata/converter.xlsx']:
 xl=pd.ExcelFile(d+'/'+rel);r[rel]={'sheets':{s:list(pd.read_excel(xl,s).shape) for s in xl.sheet_names}}
for mod in ['DTAAD_64_n','DTAAD_64_n_method_2']:
 rec={}
 for folder in ['processed/converter','insertedData/converter','viz/data','Loss/test']:
  p=b+'/'+mod+'/'+folder
  if not os.path.isdir(p):continue
  for f in os.listdir(p):
   if not f.endswith('.npy'):continue
   a=np.load(p+'/'+f,mmap_mode='r')
   rec[folder+'/'+f]={'shape':a.shape,'dtype':str(a.dtype),'sha256':hashlib.file_digest(open(p+'/'+f,'rb'),'sha256').hexdigest() if hasattr(hashlib,'file_digest') else hashlib.sha256(open(p+'/'+f,'rb').read()).hexdigest()}
 r[mod]=rec
clean=pd.read_excel(d+'/orgdata/converternew.xlsx');X=clean.iloc[:,1:].to_numpy(float)
tr=np.load(d+'/orgdata/converter_train.npy');te=np.load(d+'/orgdata/converter_test.npy')
r['normalization']={}
for nm,xx,yy in [('train',X[1:5594],tr),('test',X[5595:],te)]:
 lo=xx.min(0);span=xx.max(0)-lo;span[span==0]=1
 r['normalization'][nm]={'separate_fit_max_abs':float(abs((xx-lo)/span-yy).max()),'rows':xx.shape[0]}
lo=X[1:5594].min(0);sp=X[1:5594].max(0)-lo;sp[sp==0]=1
r['normalization']['test_train_statistics_max_abs']=float(abs((X[5595:]-lo)/sp-te).max())
for rel,a in [('orgdata/converter_train.csv',tr),('orgdata/converter_test.csv',te)]:
 c=pd.read_csv(d+'/'+rel).to_numpy();r[rel]={'csv_npy_max_abs':float(abs(a-c).max())}
trxl=pd.read_excel(d+'/orgdata/convertertrain.xlsx');texl=pd.read_excel(d+'/orgdata/convertertest.xlsx')
r['split_workbooks']={'train_equal_clean_first5594':bool(np.array_equal(trxl.iloc[:,1:].to_numpy(float),X[:5594])),'test_equal_clean_last2398':bool(np.array_equal(texl.iloc[:,1:126].to_numpy(float),X[5594:])),'test_extra_col':str(texl.columns[-1]),'test_extra_values':list(map(str,texl.iloc[:3,-1]))}
base_tr=np.load(b+'/DTAAD_64_n/processed/converter/converter_train.npy');base_te=np.load(b+'/DTAAD_64_n/processed/converter/converter_test.npy');base_la=np.load(b+'/DTAAD_64_n/processed/converter/converter_labels.npy')
r['data_links']={}
for rel in ['orgdata/converter_train.npy','orgdata/converter_test.npy','prodata/converter_train.npy','prodata/converter_test.npy','inserteddata/converter_train_seq.npy','inserteddata/converter_test_seq.npy','inserteddata/converter_labels.npy','inserteddata/converter_test_label_seq.npy']:
 a=np.load(d+'/'+rel);ref=base_la if 'label' in rel else base_tr if 'train' in rel else base_te
 r['data_links'][rel]={'equal_processed':bool(np.array_equal(a,ref)),'changed_cells':int(np.count_nonzero(a!=ref)),'max_abs':float(abs(a-ref).max())}
r['test_anomalies']={'abnormal_points':int((base_la!=0).any(1).sum()),'label_cells':int((base_la!=0).sum()),'changed_vs_clean_cells':int((base_te!=te).sum()),'unlabeled_changed_cells':int(((base_te!=te)&(base_la==0)).sum()),'labeled_unchanged_cells':int(((base_te==te)&(base_la!=0)).sum())}
print(json.dumps(r,ensure_ascii=False,indent=2))