import os,json
b='/root/gpufree-data/DTAAD';r={}
for rt,ds,fs in os.walk(b):
 ds[:]=[d for d in ds if d not in ['.git','.idea','__pycache__','showcase_exports']]
 for f in fs:
  if not f.endswith(('.py','.ipynb','.sh')):continue
  p=rt+'/'+f
  if os.path.getsize(p)>5e6:continue
  ls=open(p,errors='replace').read().splitlines();ids=[i for i,s in enumerate(ls) if any(t in s for t in ['converterold','convertertrain.xlsx','converter_train.csv','converternew.xlsx','convertertest.xlsx'])]
  if ids:r[os.path.relpath(p,b)]=[{'line':i+1,'text':ls[i]} for i in sorted(set(j for a in ids for j in range(max(0,a-4),min(a+5,len(ls)))))]
print(json.dumps(r,ensure_ascii=False,indent=2))