import sys,os,json,torch,importlib,contextlib,io
b='/root/gpufree-data/DTAAD/DTAAD_64_n_method_2';os.chdir(b);sys.path.insert(0,b);sys.argv=['audit','--model','DTAAD','--dataset','converter'];r={};ck=torch.load('checkpoints/DTAAD_converter/model.ckpt',map_location='cpu',weights_only=False)
for name in ['models','newmodels01','newmodels02','newmodels03','newmodels04']:
 try:
  with contextlib.redirect_stdout(io.StringIO()):m=importlib.import_module('src.'+name).DTAAD(125).double()
  st=m.state_dict();old=ck['model_state_dict'];r[name]={'missing_keys':sorted(set(st)-set(old)),'unexpected_keys':sorted(set(old)-set(st)),'shape_mismatches':[k for k in set(st)&set(old) if st[k].shape!=old[k].shape]}
  if name=='models':
   names=[n for n,p in m.named_parameters()];states=ck['optimizer_state_dict']['state'];paramids=ck['optimizer_state_dict']['param_groups'][0]['params'];r[name]['spatial_optimizer_states']={n:{'has_optimizer_state':pid in states,'step':float(states[pid]['step']) if pid in states else None} for n,pid in zip(names,paramids) if 'spatial' in n or 'st_fusion' in n}
 except Exception as e:r[name]={'error':str(e)}
print(json.dumps(r,indent=2))