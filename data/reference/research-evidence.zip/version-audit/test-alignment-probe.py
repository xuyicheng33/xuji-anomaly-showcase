import os,json,numpy as np
b='/root/gpufree-data/DTAAD';orig=np.load(b+'/data/dataset/prodata/converter_test.npy');test=np.load(b+'/DTAAD_64_n/processed/converter/converter_test.npy');lab=np.load(b+'/DTAAD_64_n/processed/converter/converter_labels.npy')
r={'first_orig':orig[:4,:8].tolist(),'first_test':test[:4,:8].tolist(),'first_labels':lab[:4,:8].tolist(),'last_orig':orig[-3:,:8].tolist(),'last_test':test[-3:,:8].tolist()}
for offset in [-64,-2,-1,0,1,2,64]:
 if offset>0:a,c,l=test[offset:],orig[:-offset],lab[offset:]
 elif offset<0:a,c,l=test[:offset],orig[-offset:],lab[:offset]
 else:a,c,l=test,orig,lab
 r[str(offset)]={'mean_abs':float(abs(a-c).mean()),'same_tol1e_6':int((abs(a-c)<1e-6).sum()),'unlabeled_same_tol1e_6':int(((abs(a-c)<1e-6)&(l==0)).sum())}
r['other_paths']=[]
for rt,ds,fs in os.walk(b):
 ds[:]=[d for d in ds if d not in ['.idea','__pycache__','showcase_exports']]
 for f in fs:
  if f.endswith('.npy') and any(x in f.lower() for x in ['test','original','raw']) and 'converter' in rt+'/'+f:
   p=rt+'/'+f;a=np.load(p,mmap_mode='r');r['other_paths'].append({'path':os.path.relpath(p,b),'shape':a.shape})
print(json.dumps(r,ensure_ascii=False,indent=2))