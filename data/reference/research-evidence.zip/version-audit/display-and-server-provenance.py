import os,json,hashlib,numpy as np,datetime
b='/root/gpufree-data/DTAAD';r={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_payload_hashes':{},'sources':{}}
for mod in ['DTAAD_64_n','DTAAD_64_n_method_2']:
 for f in ['converter_train.npy','converter_test.npy','converter_labels.npy']:
  p=b+'/'+mod+'/processed/converter/'+f;a=np.load(p);r['input_payload_hashes'][mod+'/'+f]=hashlib.sha256(a.astype('<f8').tobytes()).hexdigest()
 for rel in ['src/models.py','adaptive_mask.py','checkpoints/DTAAD_converter/model.ckpt']:
  p=b+'/'+mod+'/'+rel;r['sources'][p]=hashlib.sha256(open(p,'rb').read()).hexdigest()
old=np.load(b+'/DTAAD_64_n/processed/converterold/converter_test.npy');early=np.load(b+'/data/dataset/prodata/converter_test.npy');test=np.load(b+'/DTAAD_64_n/processed/converter/converter_test.npy');lab=np.load(b+'/DTAAD_64_n/processed/converter/converter_labels.npy')!=0;diff=abs(test-old)>1e-6
r['clean_payload_hashes']={'early':hashlib.sha256(early.astype('<f8').tobytes()).hexdigest(),'formal':hashlib.sha256(old.astype('<f8').tobytes()).hexdigest()}
r['label_scope']={'all_changed_times':int(diff.any(1).sum()),'changed_but_normal_times':int((diff.any(1)&~lab.any(1)).sum()),'examples_normal_times':np.flatnonzero(diff.any(1)&~lab.any(1))[:15].tolist(),'label_unchanged_cells':int(((~diff)&lab).sum())}
r['new_project_converter_checkpoints']={}
for mod in ['DTAAD_64_n1','DTAAD_64_n2']:
 r['new_project_converter_checkpoints'][mod]=[]
 for rt,ds,fs in os.walk(b+'/'+mod+'/checkpoints'):
  for f in fs:
   if f.endswith('.ckpt'):r['new_project_converter_checkpoints'][mod].append(os.path.relpath(rt+'/'+f,b))
print(json.dumps(r,indent=2))