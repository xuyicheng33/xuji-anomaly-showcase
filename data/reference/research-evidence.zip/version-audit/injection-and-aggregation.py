import os,json,ast
b='/root/gpufree-data/DTAAD';r={}
for rel in ['DTAAD_64_n/demoNew03.py','DTAAD_64_n/newMain17.py','DTAAD_64_n_method_2/newMain17.py','DTAAD_64_n/viz/viz_best.py','DTAAD_64_n_method_2/viz/viz_best.py','traditional/eval_converter_ad.py']:
 p=b+'/'+rel
 if not os.path.exists(p):continue
 t=open(p).read();ls=t.splitlines();ids=[]
 if 'newMain' in rel:
  for n in ast.parse(t).body:
   if isinstance(n,ast.FunctionDef) and n.name=='calculate_finalLoss':ids+=list(range(n.lineno-1,n.end_lineno))
 elif 'demoNew' in rel:ids=list(range(len(ls)))
 else:
  hits=[i for i,s in enumerate(ls) if any(v in s for v in ['0.031','threshold','converter','testRaw','labels','lossFinal'])];ids=sorted(set(j for i in hits for j in range(max(0,i-2),min(len(ls),i+3))))
 r[rel]=[{'line':i+1,'text':ls[i]} for i in ids]
print(json.dumps(r,ensure_ascii=False,indent=2))