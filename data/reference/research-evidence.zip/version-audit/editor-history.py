import os,json,ast,hashlib
base='/root/.cursor-server/data/User/History'
out=[]
for root,dirs,files in os.walk(base):
 if 'entries.json' not in files: continue
 try: d=json.load(open(os.path.join(root,'entries.json')))
 except: continue
 res=d.get('resource','')
 if not any(x in res.lower() for x in ['dtaad','converter','preprocess','xuji']): continue
 entries=[]
 for ent in d.get('entries',[]):
  p=os.path.join(root,ent['id'])
  if not os.path.isfile(p): continue
  t=open(p,errors='replace').read()
  hits=[{'line':i,'text':s[:250]} for i,s in enumerate(t.splitlines(),1) if ('converter' in s.lower() and any(x in s for x in ['read_','save','load','csv','xlsx'])) or any(x in s for x in ['decoder(z_final','decoder(z_time','self.st_fusion','fillna(','MinMaxScaler','train_test_split'])]
  if hits: entries.append(dict(ent,path=p,sha256=hashlib.sha256(t.encode()).hexdigest(),hits=hits))
 out.append({'resource':res,'count':len(d.get('entries',[])),'entries':entries})
print(json.dumps(out,ensure_ascii=False,indent=2))