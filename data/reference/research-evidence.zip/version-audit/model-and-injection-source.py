import os,json,ast
b='/root/gpufree-data/DTAAD';r={}
for rel in ['DTAAD_64_n_method_2/src/models.py','DTAAD_64_n_method_2/src/newmodels01.py','DTAAD_64_n_method_2/src/newmodels02.py','DTAAD_64_n_method_2/src/newmodels04.py','DTAAD_64_n/demo11.py','DTAAD_64_n_method_2/viz/regen_viz_data.py','DTAAD_64_n/viz/regen_viz_data.py','DTAAD_64_n_method_2/BNDLosswithW_single.py']:
 t=open(b+'/'+rel).read();ls=t.splitlines()
 if '/src/' in rel:
  tree=ast.parse(t);classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DTAAD'];ids=[i for n in classes for i in range(n.lineno-1,n.end_lineno)]
 else:ids=list(range(len(ls)))
 r[rel]=[{'line':i+1,'text':ls[i]} for i in ids]
print(json.dumps(r,ensure_ascii=False,indent=2))