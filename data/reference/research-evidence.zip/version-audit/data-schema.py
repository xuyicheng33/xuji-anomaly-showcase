import os,json,numpy as np,pandas as pd
b='/root/gpufree-data/DTAAD/data/dataset'
r={}
for rel in ['converter.xlsx','orgdata/converter.xlsx','orgdata/converternew.xlsx','orgdata/convertertrain.xlsx','orgdata/convertertest.xlsx']:
 p=b+'/'+rel
 df=pd.read_excel(p)
 r[rel]={'shape':df.shape,'columns':list(map(str,df.columns)),'first':df.head(2).astype(str).values.tolist(),'last':df.tail(1).astype(str).values.tolist()}
for rel in ['orgdata/converter.csv','orgdata/converter_train.csv','orgdata/converter_test.csv']:
 p=b+'/'+rel
 for h in [None,0]:
  df=pd.read_csv(p,header=h)
  r[rel+' header='+str(h)]={'shape':df.shape,'first':df.iloc[:2,:5].astype(str).values.tolist(),'columns':list(map(str,df.columns[:5]))}
for folder in ['orgdata','prodata','inserteddata']:
 for f in os.listdir(b+'/'+folder):
  if f.endswith('.npy'):
   a=np.load(b+'/'+folder+'/'+f,mmap_mode='r');r[folder+'/'+f]={'shape':a.shape,'dtype':str(a.dtype),'min':float(a.min()),'max':float(a.max())}
print(json.dumps(r,ensure_ascii=False,indent=2))