import os,json,ast,hashlib,datetime
b='/root/.cursor-server/data/User/History';r=[]
for rt,ds,fs in os.walk(b):
 if 'entries.json' not in fs:continue
 d=json.load(open(rt+'/entries.json'));res=d.get('resource','')
 if not any(x in res for x in ['/DTAAD_64_n/newMain17.py','/DTAAD_64_n_method_2/newMain17.py','/DTAAD_64_n_method_2/viz/regen_viz_data.py','/DTAAD_64_n_method_2/viz/viz_best.py']):continue
 for ent in d['entries']:
  p=rt+'/'+ent['id'];t=open(p).read();ls=t.splitlines();info={'resource':res,'path':p,'time_utc':datetime.datetime.fromtimestamp(ent['timestamp']/1000,datetime.timezone.utc).isoformat(),'sha256':hashlib.sha256(t.encode()).hexdigest()}
  names=['load_dataset','convert_to_windows','calculate_finalLoss','backprop'];info['function_hashes']={}
  try:
   for n in ast.parse(t).body:
    if isinstance(n,ast.FunctionDef) and n.name in names:info['function_hashes'][n.name]=hashlib.sha256(ast.dump(n).encode()).hexdigest()
  except:info['parse_error']=True
  info['signature_lines']=[{'line':i+1,'text':s} for i,s in enumerate(ls) if any(x in s for x in ['load_dataset(args.dataset','insert_anomalies_for_traindata(args.dataset','trainD =','lossTfinal','pot_eval(','0.031','load_state_dict','np.random.seed','manual_seed','calculate_finalLoss(lossT','model.eval()'])]
  r.append(info)
print(json.dumps(r,ensure_ascii=False,indent=2))