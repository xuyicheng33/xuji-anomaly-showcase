import os,json,torch,hashlib,re,ast
b='/root/gpufree-data/DTAAD';r={}
for mod,log,th in [('DTAAD_64_n','nohup_converter_epochs_15.log',.03153185243407894),('DTAAD_64_n_method_2','nohup_ep20.log',.03197041806617129)]:
 p=b+'/'+mod+'/checkpoints/DTAAD_converter/model.ckpt';c=torch.load(p,map_location='cpu',weights_only=False);st=c['model_state_dict'];ls=open(b+'/'+mod+'/'+log).read().splitlines()
 al=c['accuracy_list'];rec={'keys':list(c),'epoch':c['epoch'],'accuracy_list':al,'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'all_training_losses_found_in_log':all(str(x[0]) in '\n'.join(ls) for x in al),'state_shapes':{k:list(v.shape) for k,v in st.items()},'optimizer_state_count':len(c.get('optimizer_state_dict',{}).get('state',{}))}
 scans=[]
 for i,s in enumerate(ls):
  if '*****' in s and s.lstrip().startswith('{'):
   try:
    parts=s.split('*****');metrics=ast.literal_eval(parts[0].strip());candidate=float(parts[1].strip());scans.append({'line':i+1,'candidate':candidate,'metrics':metrics})
   except:pass
 if scans:
  rec['scan_count']=len(scans);rec['scan_best']=max(scans,key=lambda x:x['metrics']['f1']);rec['selected']=[x for x in scans if abs(x['candidate']-th)<1e-14];rec['log_tail']=ls[-18:]
 r[mod]=rec
print(json.dumps(r,ensure_ascii=False,indent=2,default=str))