import os,json,hashlib,numpy as np,pandas as pd
b='/root/gpufree-data/DTAAD';r={};x=pd.read_excel(b+'/data/dataset/orgdata/convertertrain.xlsx').iloc[1:,1:].to_numpy(float);y=pd.read_excel(b+'/data/dataset/orgdata/convertertest.xlsx').iloc[1:,1:126].to_numpy(float);lo=x.min(0);span=x.max(0)-lo;span[span==0]=1;norm=(y-lo)/span
old=np.load(b+'/DTAAD_64_n/processed/converterold/converter_test.npy');test=np.load(b+'/DTAAD_64_n/processed/converter/converter_test.npy');label=np.load(b+'/DTAAD_64_n/processed/converter/converter_labels.npy')!=0
r['old_normalization']={'max_abs':float(abs(old-norm).max()),'changed_gt1e_8':int((abs(old-norm)>1e-8).sum()),'old_min':float(old.min()),'old_max':float(old.max()),'norm_min':float(norm.min()),'norm_max':float(norm.max()),'clip_max_abs':float(abs(old-np.clip(norm,0,1)).max()),'clip_changed_gt1e_8':int((abs(old-np.clip(norm,0,1))>1e-8).sum())}
for rel in ['DTAAD_64_n/processed/converterold','DTAAD_64_n_method_2/processed/converterold']:
 r[rel]={}
 for f in os.listdir(b+'/'+rel):
  if f.endswith('.npy'):
   p=b+'/'+rel+'/'+f;a=np.load(p);r[rel][f]={'shape':a.shape,'sha256':hashlib.sha256(open(p,'rb').read()).hexdigest(),'min':float(a.min()),'max':float(a.max())}
for offset in [-1,0,1]:
 if offset<0:a,c,l=test[:offset],old[-offset:],label[:offset]
 elif offset>0:a,c,l=test[offset:],old[:-offset],label[offset:]
 else:a,c,l=test,old,label
 df=abs(a-c);r['offset_'+str(offset)]={'changed_gt1e_6':int((df>1e-6).sum()),'unlabeled_changed_gt1e_6':int(((df>1e-6)&~l).sum()),'labeled_unchanged_gt1e_6':int(((df<=1e-6)&l).sum())}
diff=abs(test-old)>1e-6;bad=diff&~label;pt=label.any(1)
r['unlabeled_differences']={'changed_unlabeled_cells':int(bad.sum()),'changed_at_labeled_time':int((bad&pt[:,None]).sum()),'changed_at_unlabeled_time':int((bad&~pt[:,None]).sum()),'examples':[{'row':int(i),'feature':int(j),'old':float(old[i,j]),'new':float(test[i,j]),'point_labeled':bool(pt[i])} for i,j in np.argwhere(bad)[:12]]}
print(json.dumps(r,indent=2))