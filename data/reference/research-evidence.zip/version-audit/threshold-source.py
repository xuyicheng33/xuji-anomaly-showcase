import os,json,re,ast
b='/root/gpufree-data/DTAAD';r={}
for mod in ['DTAAD_64_n','DTAAD_64_n_method_2']:
 for root,ds,fs in os.walk(b+'/'+mod):
  ds[:]=[d for d in ds if d not in ['.idea','__pycache__','processed','insertedData','checkpoints','Loss','viz','result','plots']]
  for f in fs:
   if not f.endswith(('.py','.log','.txt','.sh')):continue
   p=root+'/'+f
   if os.path.getsize(p)>40e6:continue
   ls=open(p,errors='replace').read().splitlines()
   nums=[i for i,s in enumerate(ls) if any(v in s for v in ['0.031531','0.031970'])]
   if f.startswith('nohup') and not nums:
    nums=[i for i,s in enumerate(ls) if ('threshold' in s.lower() or 'Epoch 14' in s or 'Epoch 19' in s or 'Testing DTAAD on converter' in s)]
   if f in ['newMain17.py','1vize.py','save_score.py','calc_cm.py','plot_score_distribution.py','pot.py','constants.py','parser.py']:
    nums=list(range(len(ls)))
   if nums:
    ids=sorted(set(j for i in nums for j in range(max(0,i-2),min(len(ls),i+3))))
    r[os.path.relpath(p,b)]=[{'line':i+1,'text':ls[i]} for i in ids][:3000]
print(json.dumps(r,ensure_ascii=False,indent=2))