import json,base64,numpy as np
from pathlib import Path
r=Path('.qa/curve-analysis-20261029');root=Path('public/data/journey')
manifest=json.loads((root/'manifest.json').read_text('utf8'))
results=[]
for model in manifest['models']:
 file=r/('inference-'+model['id']+'.json')
 if not file.exists():continue
 d=json.loads(json.loads(file.read_text('utf8'))['stdout'])
 pred=np.frombuffer(base64.b64decode(d.pop('predictionFloat32Base64')),dtype='<f4').reshape(-1,64,125)
 diffs=[]
 for i,start in enumerate(d['starts']):
  chunk=next(c for c in model['windows']['chunks'] if c['start']<=start<c['start']+c['count'])
  saved=np.fromfile(root/chunk['file'],dtype='<f4').reshape(chunk['count'],64,125)[start-chunk['start']]
  diffs.append(float(np.max(np.abs(saved-pred[i]))))
 d['maxDifferenceFromPublishedWindow']=max(diffs)
 d['flattenResponseRatio']=d['flattenTimeOutputRMSE']/d['flattenTimeInputRMSE']
 d['reverseResponseRatio']=d['reverseTimeOutputRMSE']/d['reverseTimeInputRMSE']
 results.append(d)
(r/'inference-summary.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))

