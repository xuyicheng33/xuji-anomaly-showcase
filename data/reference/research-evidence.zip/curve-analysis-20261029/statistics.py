from pathlib import Path
import json,hashlib
import numpy as np

ROOT=Path.cwd()
OUT=ROOT/'.qa/curve-analysis-20261029'
FOLDER=ROOT/'public/data/journey'
data=json.loads((FOLDER/'manifest.json').read_text('utf8'))
def load(a):
 return np.fromfile(FOLDER/a['file'],dtype='<f8').reshape(a['shape'])
x=load(data['input']);clean=load(data['cleanTest']);labels=load(data['labelMatrix'])>0
y=np.array(data['labels'],bool);T,F=x.shape
train=np.load(ROOT/'data/source/dataset/prodata/converter_train.npy')
pair_normal=~(y[:-1]|y[1:])
def numbers(a):
 return {'min':float(np.min(a)),'max':float(np.max(a)),'sd':float(np.std(a)),'step':float(np.abs(np.diff(a,axis=0)).mean())}
def safe_ratios(a,b,limit=1e-7):
 mask=b>limit
 return {'median':float(np.median(a[mask]/b[mask])),'p10':float(np.percentile(a[mask]/b[mask],10)),'p90':float(np.percentile(a[mask]/b[mask],90)),'underHalf':int(np.sum(a[mask]/b[mask]<.5)),'count':int(mask.sum())}
def masked_step(a):
 return float(np.abs(np.diff(a,axis=0))[pair_normal].mean())
result={'data':{'shape':list(x.shape),'cleanStep':float(np.abs(np.diff(clean,axis=0)).mean()),'inputStep':float(np.abs(np.diff(x,axis=0)).mean()),'normalInputStep':masked_step(x),'cleanConstantColumns':int((clean.std(0)<1e-8).sum()),'trainConstantColumns':int((train.std(0)<1e-8).sum()),'trainAtZero':float((train==0).mean()),'trainAtOne':float((train==1).mean()),'abnormalRows':int(y.sum()),'changedNormalCells':int(((np.abs(x-clean)>1e-8)&~labels).sum())},'models':[]}
plot={'input':x,'clean':clean,'labels':y}
for m in data['models']:
 recon=load(m['recon'])
 windows=np.concatenate([np.fromfile(FOLDER/c['file'],dtype='<f4').reshape(c['count'],64,F) for c in m['windows']['chunks']])
 input_windows=np.lib.stride_tricks.sliding_window_view(x,64,axis=0).transpose(0,2,1)
 wsteps=np.mean(np.abs(np.diff(windows,axis=1)),axis=(0,1))
 xsteps=np.mean(np.abs(np.diff(input_windows,axis=1)),axis=(0,1))
 rsteps=np.mean(np.abs(np.diff(recon,axis=0)),axis=0)
 steps=np.mean(np.abs(np.diff(x,axis=0)),axis=0)
 # Normal-time errors against the observed and clean inputs, compared to train mean.
 baseline=np.broadcast_to(train.mean(0),x.shape)
 normal_metrics={'inputStep':masked_step(x),'reconStep':masked_step(recon),
 'modelMSE':float(((x-recon)**2)[~y].mean()),'trainMeanMSE':float(((x-baseline)**2)[~y].mean()),
 'modelCleanMSE':float(((clean-recon)**2)[~y].mean())}
 correlations=[]
 for f in range(F):
  if x[~y,f].std()>1e-6 and recon[~y,f].std()>1e-6:
   correlations.append(float(np.corrcoef(x[~y,f],recon[~y,f])[0,1]))
 relative_template=windows.mean(0)
 residual=windows-relative_template[None]
 examples=[]
 for start in [0,107,500,1000,1800,2333]:
  stop=start+64
  examples.append({'start':start+1,'end':stop,
   'inputMean':numbers(x[start:stop].mean(1)),
   'windowMean':numbers(windows[start].mean(1)),
   'playbackMean':numbers(recon[start:stop].mean(1)),
   'sensors':[{'index':f,'key':data['features'][f]['key'],'label':data['features'][f]['label'],'input':numbers(x[start:stop,f]),'clean':numbers(clean[start:stop,f]),'window':numbers(windows[start,:,f]),'playback':numbers(recon[start:stop,f])} for f in [0,4,5,16,24]]})
 feats=[{'index':f,'key':data['features'][f]['key'],'label':data['features'][f]['label'],'inputSD':float(x[:,f].std()),'reconSD':float(recon[:,f].std()),'inputStep':float(steps[f]),'windowStep':float(wsteps[f]),'reconStep':float(rsteps[f]),'normalMSE':float(((x[:,f]-recon[:,f])**2)[~y].mean())} for f in range(F)]
 model={'id':m['id'],'name':m['name'],'reconstruction':numbers(recon),'normalMetrics':normal_metrics,'windowStep':float(wsteps.mean()),'inputWindowStep':float(xsteps.mean()),'playbackStep':float(rsteps.mean()),'defaultMeanInputStep':float(np.abs(np.diff(x.mean(1))).mean()),'defaultMeanWindowStep':float(np.abs(np.diff(windows.mean(2),axis=1)).mean()),'defaultMeanPlaybackStep':float(np.abs(np.diff(recon.mean(1))).mean()),'windowVsInputByFeature':safe_ratios(wsteps,xsteps),'playbackVsInputByFeature':safe_ratios(rsteps,steps),'playbackVsWindowByFeature':safe_ratios(rsteps,wsteps),'normalCorrelationMedian':float(np.median(correlations)),'normalCorrelationBelowPoint2':int(np.sum(np.array(correlations)<.2)),'relativePositionTemplateRMSE':float(np.sqrt(np.mean(residual**2))),'reconAllSD':float(windows.std()),'acrossWindowVariationPerPositionMedian':float(np.median(windows.std(0))),'examples':examples,'features':feats}
 result['models'].append(model)
 plot[m['id']+'_recon']=recon
 plot[m['id']+'_window108']=windows[107]
 # Assess dramatic y-axis changes between adjacent playback positions.
 ranges=[]
 for count in range(1,T+1):
  idx=count-1;start=max(0,min(T-64,idx-40))
  vals=np.r_[x[start:start+64].mean(1),recon[start:start+64].mean(1)]
  lo,hi=vals.min(),vals.max();pad=max((hi-lo)*.12,abs(hi)*1e-9,1e-12)
  ranges.append((max(0,lo-pad),hi+pad))
 ranges=np.array(ranges)
 jumps=np.max(abs(np.diff(ranges,axis=0)),axis=1)
 largest=np.argsort(jumps)[-5:][::-1]
 model['axisJumps']=[{'countBefore':int(i+1),'countAfter':int(i+2),'before':ranges[i].tolist(),'after':ranges[i+1].tolist(),'delta':float(jumps[i])} for i in largest]
 del windows,input_windows,residual
(OUT/'statistics.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
np.savez_compressed(OUT/'plot-data.npz',**plot)
print(json.dumps({'data':result['data'],'models':[{k:v for k,v in m.items() if k not in ['features','examples']} for m in result['models']]},ensure_ascii=False,indent=2))

