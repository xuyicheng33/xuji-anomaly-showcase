from pathlib import Path
import numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
r=Path('.qa/curve-analysis-20261029')
font=FontProperties(fname='C:/Windows/Fonts/msyh.ttc')
plt.rcParams['font.sans-serif']=['Microsoft YaHei']
plt.rcParams['axes.unicode_minus']=False
a=np.load(r/'plot-data.npz');s=107;end=171;t=np.arange(s+1,end+1)
fig,axes=plt.subplots(2,2,figsize=(13,7),dpi=160,sharex=True)
for i,mid in enumerate(['model1','model2']):
 for j,f in enumerate([-1,4]):
  ax=axes[i,j]
  inp=a['input'][s:end].mean(1) if f<0 else a['input'][s:end,f]
  win=a[mid+'_window108'].mean(1) if f<0 else a[mid+'_window108'][:,f]
  agg=a[mid+'_recon'][s:end].mean(1) if f<0 else a[mid+'_recon'][s:end,f]
  ax.plot(t,inp,color='#283c4c',lw=1.6,label='输入')
  ax.plot(t,win,color='#9baeb8',lw=1.3,label='单个64点窗口重建')
  ax.plot(t,agg,color='#258077',lw=2.1,label='跨窗口平均后的回放重建')
  ax.set_title(('STAM-AD' if i==0 else 'SMST-AD')+' · '+('125测点平均' if f<0 else '直流电流 21B12_R1_IDCH_a'),fontproperties=font,fontsize=11)
  ax.grid(axis='y',alpha=.18);ax.spines[['top','right']].set_visible(False)
  ax.set_ylabel('归一化值',fontproperties=font)
  if i==1:ax.set_xlabel('测试序列中的时刻编号',fontproperties=font)
  ax.legend(prop=font,fontsize=8,loc='best')
fig.suptitle('同一段数据：原始单窗重建与回放重建的差别',fontproperties=font,fontsize=16,y=1.02)
fig.tight_layout();fig.savefig(r/'reconstruction-comparison.png',bbox_inches='tight',facecolor='#f8f7f3')
plt.close(fig)
print(r/'reconstruction-comparison.png')

